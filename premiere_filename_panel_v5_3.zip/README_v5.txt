v5.3: adds GitHub-based update checking and zip download from a configured owner/repo release feed, plus keeps v5.2 visibility, occlusion, scan-range, and Ignore V1 behavior.
