function filenameCourtesyPanel_run(mogrtPath, textParamName, targetTrackNumberOneBased, scanUpToTrackNumberOneBased, minDurationSeconds, suffix, maxDisplaySeconds, ignoreV1) {
    function fileExists(path) {
        try { var f = new File(path); return f.exists; } catch (e) { return false; }
    }
    function removeExtension(filename) { return String(filename).replace(/\.[^\.]+$/, ""); }
    function trimString(s) { return String(s).replace(/^\s+|\s+$/g, ""); }
    function extractAfterAt(filename) {
        var base = removeExtension(filename);
        var atPos = base.lastIndexOf("@");
        if (atPos === -1 || atPos === base.length - 1) { return null; }
        return trimString(base.substring(atPos + 1));
    }
    function buildCourtesyText(keyAfterAt, suffix) {
        var cleanSuffix = trimString(suffix || "Thank you.");
        if (cleanSuffix.length === 0) { cleanSuffix = "Thank you."; }
        return "Footage courtesy of " + keyAfterAt + ". " + cleanSuffix;
    }
    function getClipDisplayName(trackItem) {
        try { if (trackItem.projectItem && trackItem.projectItem.name) { return String(trackItem.projectItem.name); } } catch (e) {}
        try { if (trackItem.name) { return String(trackItem.name); } } catch (e2) {}
        return null;
    }
    function ticksToSeconds(ticksValue) {
        var ticks = Number(ticksValue);
        if (!isFinite(ticks)) { return 0; }
        return ticks / 254016000000.0;
    }
    function secondsToTicks(secondsValue) {
        var secs = Number(secondsValue);
        if (!isFinite(secs) || secs < 0) { secs = 0; }
        return Math.round(secs * 254016000000.0);
    }
    function clipDurationSeconds(clip) {
        try { return ticksToSeconds(Number(clip.end.ticks) - Number(clip.start.ticks)); } catch (e) { return 0; }
    }
    function getTrackCount(videoTracks) {
        if (typeof videoTracks.numTracks !== 'undefined') { return videoTracks.numTracks; }
        if (typeof videoTracks.length !== 'undefined') { return videoTracks.length; }
        return 0;
    }
    function ensureVideoTrackExists(seq, targetTrackIndexZeroBased) {
        var currentCount = getTrackCount(seq.videoTracks);
        if (currentCount === 0) { return false; }
        while (currentCount <= targetTrackIndexZeroBased) {
            try { seq.videoTracks[currentCount - 1].insertTrack(); } catch (e) { break; }
            currentCount = getTrackCount(seq.videoTracks);
            if (currentCount > targetTrackIndexZeroBased) { break; }
        }
        return getTrackCount(seq.videoTracks) > targetTrackIndexZeroBased;
    }
    function getParamByDisplayName(component, displayName) {
        if (!component || !component.properties || !component.properties.numItems) { return null; }
        for (var i = 0; i < component.properties.numItems; i++) {
            var p = component.properties[i];
            if (p && p.displayName === displayName) { return p; }
        }
        return null;
    }
    function setMogrtText(trackItem, paramName, newText) {
        var mogrtComponent = trackItem.getMGTComponent();
        if (!mogrtComponent) { throw new Error('Could not get MOGRT component.'); }
        var textParam = getParamByDisplayName(mogrtComponent, paramName);
        if (!textParam) { throw new Error('Could not find MOGRT text parameter: ' + paramName); }
        var raw = textParam.getValue();
        try {
            var parsed = JSON.parse(raw);
            if (parsed.hasOwnProperty('textEditValue')) { parsed.textEditValue = newText; }
            if (parsed.hasOwnProperty('fontTextRunLength')) { parsed.fontTextRunLength = [newText.length]; }
            textParam.setValue(JSON.stringify(parsed), true);
        } catch (e) {
            textParam.setValue(newText, true);
        }
    }
    function makeTimeFromTicks(ticks) {
        var t = new Time();
        t.ticks = String(Math.round(Number(ticks)));
        return t;
    }
    function sameTickValue(a, b) {
        return String(Math.round(Number(a))) === String(Math.round(Number(b)));
    }
    function readSequenceBoundaryTicks(seq, methodName, propertyName) {
        try {
            if (seq && typeof seq[methodName] === 'function') {
                var result = seq[methodName]();
                if (result && typeof result.ticks !== 'undefined') {
                    var methodTicks = Number(result.ticks);
                    if (isFinite(methodTicks)) { return methodTicks; }
                }
                var directMethodValue = Number(result);
                if (isFinite(directMethodValue)) { return directMethodValue; }
            }
        } catch (e) {}
        try {
            if (seq && seq[propertyName] && typeof seq[propertyName].ticks !== 'undefined') {
                var propTicks = Number(seq[propertyName].ticks);
                if (isFinite(propTicks)) { return propTicks; }
            }
        } catch (e2) {}
        try {
            if (seq && typeof seq[propertyName] !== 'undefined') {
                var directPropValue = Number(seq[propertyName]);
                if (isFinite(directPropValue)) { return directPropValue; }
            }
        } catch (e3) {}
        return null;
    }
    function getTrackClipCollection(track) {
        if (track && track.clips && track.clips.numItems) { return track.clips; }
        return null;
    }
    function normalizeBoolean(value) {
        if (typeof value === 'boolean') { return value; }
        if (typeof value === 'number') { return value !== 0; }
        if (typeof value === 'string') {
            var normalized = value.toLowerCase();
            if (normalized === 'true' || normalized === 'on' || normalized === 'yes' || normalized === '1') { return true; }
            if (normalized === 'false' || normalized === 'off' || normalized === 'no' || normalized === '0') { return false; }
        }
        return null;
    }
    function readBooleanFlag(obj, propertyNames) {
        if (!obj) { return null; }
        for (var i = 0; i < propertyNames.length; i++) {
            var propertyName = propertyNames[i];
            try {
                var value = obj[propertyName];
                if (typeof value === 'function') { value = value.call(obj); }
                var normalized = normalizeBoolean(value);
                if (normalized !== null) { return normalized; }
            } catch (e) {}
        }
        return null;
    }
    function isObjectVisibleAndActive(obj) {
        var disabled = readBooleanFlag(obj, ['disabled', 'isDisabled']);
        if (disabled === true) { return false; }
        var enabled = readBooleanFlag(obj, ['enabled', 'isEnabled']);
        if (enabled === false) { return false; }
        var active = readBooleanFlag(obj, ['active', 'isActive']);
        if (active === false) { return false; }
        var hidden = readBooleanFlag(obj, ['hidden', 'isHidden']);
        if (hidden === true) { return false; }
        var visible = readBooleanFlag(obj, ['visible', 'isVisible']);
        if (visible === false) { return false; }
        return true;
    }
    function rangesOverlap(startA, endA, startB, endB) {
        return endA > startB && endB > startA;
    }
    function isCoveredByHigherVisibleClip(seq, clipTrackIndex, startTicks, endTicks, targetTrackIndexZeroBased, maxTrackIndexToScan) {
        var availableTrackCount = getTrackCount(seq.videoTracks);
        var lastTrackIndexToCheck = availableTrackCount - 1;
        if (isFinite(maxTrackIndexToScan) && maxTrackIndexToScan < lastTrackIndexToCheck) {
            lastTrackIndexToCheck = maxTrackIndexToScan;
        }
        for (var higherTrackIndex = clipTrackIndex + 1; higherTrackIndex <= lastTrackIndexToCheck; higherTrackIndex++) {
            if (higherTrackIndex === targetTrackIndexZeroBased) { continue; }
            var higherTrack = seq.videoTracks[higherTrackIndex];
            if (!higherTrack || !isObjectVisibleAndActive(higherTrack) || !higherTrack.clips || !higherTrack.clips.numItems) { continue; }
            for (var clipIndex = 0; clipIndex < higherTrack.clips.numItems; clipIndex++) {
                var higherClip = higherTrack.clips[clipIndex];
                if (!higherClip || !isObjectVisibleAndActive(higherClip)) { continue; }
                try {
                    var higherStartTicks = Number(higherClip.start.ticks);
                    var higherEndTicks = Number(higherClip.end.ticks);
                    if (isFinite(higherStartTicks) && isFinite(higherEndTicks) && rangesOverlap(startTicks, endTicks, higherStartTicks, higherEndTicks)) {
                        return true;
                    }
                } catch (e) {}
            }
        }
        return false;
    }
    function getSequenceEndTicks(seq) {
        var maxEndTicks = 0;
        var trackCollections = [seq.videoTracks, seq.audioTracks];
        for (var groupIndex = 0; groupIndex < trackCollections.length; groupIndex++) {
            var tracks = trackCollections[groupIndex];
            var trackCount = getTrackCount(tracks);
            for (var trackIndex = 0; trackIndex < trackCount; trackIndex++) {
                var track = tracks[trackIndex];
                var clips = getTrackClipCollection(track);
                if (!clips) { continue; }
                for (var clipIndex = 0; clipIndex < clips.numItems; clipIndex++) {
                    var clip = clips[clipIndex];
                    if (!clip) { continue; }
                    try {
                        var clipEndTicks = Number(clip.end.ticks);
                        if (isFinite(clipEndTicks) && clipEndTicks > maxEndTicks) {
                            maxEndTicks = clipEndTicks;
                        }
                    } catch (e) {}
                }
            }
        }
        return maxEndTicks;
    }
    function getProcessingRange(seq) {
        var inTicks = readSequenceBoundaryTicks(seq, 'getInPointAsTime', 'inPoint');
        if (!isFinite(inTicks)) { inTicks = readSequenceBoundaryTicks(seq, 'getInPoint', 'inPoint'); }
        var outTicks = readSequenceBoundaryTicks(seq, 'getOutPointAsTime', 'outPoint');
        if (!isFinite(outTicks)) { outTicks = readSequenceBoundaryTicks(seq, 'getOutPoint', 'outPoint'); }

        if (isFinite(inTicks) && isFinite(outTicks) && outTicks > inTicks) {
            return {
                startTicks: inTicks,
                endTicks: outTicks,
                mode: 'in_out'
            };
        }

        return {
            startTicks: 0,
            endTicks: getSequenceEndTicks(seq),
            mode: 'full_sequence'
        };
    }

    function collectEligibleClips(seq, minDurationSeconds, targetTrackIndexZeroBased, scanUpToTrackNumberOneBased, processingRange) {
        var availableTrackCount = getTrackCount(seq.videoTracks);
        var bestByKey = {};
        var logs = [];
        var maxTrackIndexToScan = Number(scanUpToTrackNumberOneBased) - 1;
        if (!isFinite(maxTrackIndexToScan) || maxTrackIndexToScan < 0) { maxTrackIndexToScan = availableTrackCount - 1; }
        if (maxTrackIndexToScan > availableTrackCount - 1) { maxTrackIndexToScan = availableTrackCount - 1; }

        for (var trackIndex = 0; trackIndex <= maxTrackIndexToScan; trackIndex++) {
            if (trackIndex === targetTrackIndexZeroBased) { continue; }
            if (ignoreV1 && trackIndex === 0) {
                logs.push('SKIP: V1 ignored by checkbox setting');
                continue;
            }
            var track = seq.videoTracks[trackIndex];
            if (!track || !track.clips || !track.clips.numItems) { continue; }
            if (!isObjectVisibleAndActive(track)) {
                logs.push('SKIP: inactive or hidden track V' + (trackIndex + 1));
                continue;
            }

            for (var i = 0; i < track.clips.numItems; i++) {
                var clip = track.clips[i];
                if (!clip) { continue; }
                if (!isObjectVisibleAndActive(clip)) {
                    var hiddenName = getClipDisplayName(clip) || ('clip on V' + (trackIndex + 1));
                    logs.push('SKIP: hidden or inactive -> ' + hiddenName);
                    continue;
                }

                var clipName = getClipDisplayName(clip);
                if (!clipName) { logs.push('SKIP: unnamed clip on V' + (trackIndex + 1)); continue; }

                var keyAfterAt = extractAfterAt(clipName);
                if (!keyAfterAt) { logs.push('SKIP: no @ segment -> ' + clipName); continue; }

                var startTicks = Number(clip.start.ticks);
                var runEndTicks = Number(clip.end.ticks);
                var overlapStartTicks = startTicks > processingRange.startTicks ? startTicks : processingRange.startTicks;
                var overlapEndTicks = runEndTicks < processingRange.endTicks ? runEndTicks : processingRange.endTicks;
                var runDurationSeconds = ticksToSeconds(overlapEndTicks - overlapStartTicks);
                var runNames = [clipName];

                var j = i + 1;
                while (j < track.clips.numItems) {
                    var nextClip = track.clips[j];
                    if (!nextClip) { break; }

                    var nextName = getClipDisplayName(nextClip);
                    var nextKey = nextName ? extractAfterAt(nextName) : null;

                    if (!nextKey || nextKey !== keyAfterAt) { break; }
                    if (!sameTickValue(nextClip.start.ticks, runEndTicks)) { break; }

                    runEndTicks = Number(nextClip.end.ticks);
                    overlapStartTicks = startTicks > processingRange.startTicks ? startTicks : processingRange.startTicks;
                    overlapEndTicks = runEndTicks < processingRange.endTicks ? runEndTicks : processingRange.endTicks;
                    runDurationSeconds = ticksToSeconds(overlapEndTicks - overlapStartTicks);
                    runNames.push(nextName);
                    j++;
                }

                if (overlapEndTicks <= overlapStartTicks) {
                    logs.push('SKIP: outside selected range -> ' + runNames.join(' | '));
                    i = j - 1;
                    continue;
                }

                if (isCoveredByHigherVisibleClip(seq, trackIndex, overlapStartTicks, overlapEndTicks, targetTrackIndexZeroBased, maxTrackIndexToScan)) {
                    logs.push('SKIP: covered by higher visible track within selected scan range -> ' + runNames.join(' | '));
                    i = j - 1;
                    continue;
                }

                if (runDurationSeconds < minDurationSeconds) {
                    if (runNames.length > 1) {
                        logs.push('SKIP: consecutive run too short (' + runDurationSeconds.toFixed(2) + 's) -> ' + runNames.join(' | '));
                    } else {
                        logs.push('SKIP: too short (' + runDurationSeconds.toFixed(2) + 's) -> ' + clipName);
                    }
                    i = j - 1;
                    continue;
                }

                if (!bestByKey.hasOwnProperty(keyAfterAt) || startTicks < bestByKey[keyAfterAt].startTicks) {
                    bestByKey[keyAfterAt] = {
                        keyAfterAt: keyAfterAt,
                        clipName: clipName,
                        startTicks: overlapStartTicks,
                        endTicks: overlapEndTicks,
                        trackIndex: trackIndex,
                        durationSeconds: runDurationSeconds
                    };
                }

                i = j - 1;
            }
        }

        var collected = [];
        for (var key in bestByKey) {
            if (bestByKey.hasOwnProperty(key)) { collected.push(bestByKey[key]); }
        }
        collected.sort(function(a, b) { return a.startTicks - b.startTicks; });
        return { clips: collected, logs: logs };
    }

    function insertCourtesyClip(seq, targetTrackIndexZeroBased, mogrtPath, textParamName, item, suffix, maxDisplaySeconds) {
        var inserted = seq.importMGT(mogrtPath, String(item.startTicks), targetTrackIndexZeroBased, 0);
        if (!inserted) { throw new Error('importMGT failed.'); }
        var finalText = buildCourtesyText(item.keyAfterAt, suffix);
        setMogrtText(inserted, textParamName, finalText);
        var actualSeconds = item.durationSeconds;
        var maxSecs = Number(maxDisplaySeconds);
        if (!isFinite(maxSecs) || maxSecs <= 0) { maxSecs = 3; }
        var displaySeconds = actualSeconds < maxSecs ? actualSeconds : maxSecs;
        try {
            inserted.end = makeTimeFromTicks(item.startTicks + secondsToTicks(displaySeconds));
        } catch (e) {
            try { inserted.end = item.end; } catch (e2) {}
        }
        return { text: finalText, displaySeconds: displaySeconds };
    }

    try {
        if (!app.project) { return 'FAIL: No project is open.'; }
        var seq = app.project.activeSequence;
        if (!seq) { return 'FAIL: No active sequence.'; }
        if (!fileExists(mogrtPath)) { return 'FAIL: MOGRT file not found: ' + mogrtPath; }

        var targetTrackIndex = Number(targetTrackNumberOneBased) - 1;
        if (!isFinite(targetTrackIndex) || targetTrackIndex < 0) { return 'FAIL: Invalid target track.'; }

        var durationCutoff = Number(minDurationSeconds);
        if (!isFinite(durationCutoff) || durationCutoff < 0) { durationCutoff = 2; }

        var maxSecs = Number(maxDisplaySeconds);
        if (!isFinite(maxSecs) || maxSecs <= 0) { maxSecs = 3; }

        if (!ensureVideoTrackExists(seq, targetTrackIndex)) {
            return 'FAIL: Could not create or access target video track V' + (targetTrackIndex + 1) + '.';
        }

        var scanUpToTrackNumberOneBased = Number(scanUpToTrackNumberOneBased);
        if (!isFinite(scanUpToTrackNumberOneBased) || scanUpToTrackNumberOneBased < 1) { scanUpToTrackNumberOneBased = 8; }
        var processingRange = getProcessingRange(seq);
        var collected = collectEligibleClips(seq, durationCutoff, targetTrackIndex, scanUpToTrackNumberOneBased, processingRange);
        var clips = collected.clips;
        var lines = [];
        var processed = 0;
        var failed = 0;

        lines.push('Scanning source tracks: V1 to V' + scanUpToTrackNumberOneBased + ' where available, excluding the target text track');
        lines.push('Target text track: V' + (targetTrackIndex + 1));
        lines.push('Minimum duration: ' + durationCutoff + 's');
        lines.push('Maximum courtesy duration: ' + maxSecs + 's');
        if (processingRange.mode === 'in_out') {
            lines.push('Processing range: active In/Out selection (' + ticksToSeconds(processingRange.endTicks - processingRange.startTicks).toFixed(2) + 's)');
        } else {
            lines.push('Processing range: full active sequence (' + ticksToSeconds(processingRange.endTicks - processingRange.startTicks).toFixed(2) + 's)');
        }
        lines.push('Unique key: text after @');
        lines.push('Consecutive same-key cuts: combined before minimum-duration check');
        lines.push('');

        if (clips.length === 0) {
            lines.push('No eligible clips found.');
            if (collected.logs.length) {
                lines.push('');
                lines.push('Details:');
                for (var dl = 0; dl < collected.logs.length; dl++) { lines.push(collected.logs[dl]); }
            }
            return lines.join('\n');
        }

        for (var i = 0; i < clips.length; i++) {
            var item = clips[i];
            try {
                var result = insertCourtesyClip(seq, targetTrackIndex, mogrtPath, textParamName, item, suffix, maxSecs);
                processed++;
                lines.push('OK: ' + item.clipName + ' -> ' + result.text + ' [' + result.displaySeconds.toFixed(2) + 's]');
            } catch (e) {
                failed++;
                lines.push('FAIL: ' + item.clipName + ' -> Error: ' + e);
            }
        }

        if (collected.logs.length) {
            lines.push('');
            lines.push('Skipped while scanning:');
            for (var sl = 0; sl < collected.logs.length; sl++) { lines.push(collected.logs[sl]); }
        }

        lines.push('');
        lines.push('Summary: processed ' + processed + ', failed ' + failed + ', unique eligible sources ' + clips.length + '.');
        return lines.join('\n');
    } catch (fatal) {
        return 'FAIL: ' + fatal;
    }
}
var filenameCourtesyPanel = { run: filenameCourtesyPanel_run };






function filenameCourtesyPanel_getUpdaterContext() {
    try {
        var jsxFile = new File($.fileName);
        var rootFolder = jsxFile.parent.parent;
        var manifestFile = new File(rootFolder.fsName + '/CSXS/manifest.xml');
        var currentVersion = 'Unknown';

        if (manifestFile.exists && manifestFile.open('r')) {
            var manifestContents = manifestFile.read();
            manifestFile.close();
            var match = manifestContents.match(/ExtensionBundleVersion="([^"]+)"/);
            if (match && match[1]) {
                currentVersion = String(match[1]);
            }
        }

        var updatesFolder = new Folder(rootFolder.fsName + '/updates');
        if (!updatesFolder.exists) {
            updatesFolder.create();
        }

        return JSON.stringify({
            currentVersion: currentVersion,
            extensionRoot: rootFolder.fsName,
            updatesFolder: updatesFolder.fsName
        });
    } catch (e) {
        return 'FAIL: ' + e;
    }
}

function filenameCourtesyPanel_base64ToBinary(base64Text) {
    var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var clean = String(base64Text || '').replace(/[^A-Za-z0-9\+\/\=]/g, '');
    var output = [];
    var i;

    for (i = 0; i < clean.length; i += 4) {
        var enc1 = alphabet.indexOf(clean.charAt(i));
        var enc2 = alphabet.indexOf(clean.charAt(i + 1));
        var enc3Char = clean.charAt(i + 2);
        var enc4Char = clean.charAt(i + 3);
        var enc3 = enc3Char === '=' ? 64 : alphabet.indexOf(enc3Char);
        var enc4 = enc4Char === '=' ? 64 : alphabet.indexOf(enc4Char);

        var chr1 = (enc1 << 2) | (enc2 >> 4);
        output.push(String.fromCharCode(chr1));

        if (enc3 !== 64) {
            var chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            output.push(String.fromCharCode(chr2));
        }

        if (enc4 !== 64) {
            var chr3 = ((enc3 & 3) << 6) | enc4;
            output.push(String.fromCharCode(chr3));
        }
    }

    return output.join('');
}

function filenameCourtesyPanel_beginUpdateWrite(targetPath) {
    try {
        var targetFile = new File(targetPath);
        var parentFolder = targetFile.parent;
        if (parentFolder && !parentFolder.exists) {
            parentFolder.create();
        }
        if (targetFile.exists) {
            try { targetFile.remove(); } catch (removeError) {}
        }
        targetFile.encoding = 'BINARY';
        if (!targetFile.open('w')) {
            return 'FAIL: Could not open update file for writing.';
        }
        targetFile.close();
        return 'OK';
    } catch (e) {
        return 'FAIL: ' + e;
    }
}

function filenameCourtesyPanel_appendUpdateChunk(targetPath, base64Chunk) {
    try {
        var targetFile = new File(targetPath);
        targetFile.encoding = 'BINARY';
        if (!targetFile.open('a')) {
            return 'FAIL: Could not append update data.';
        }
        targetFile.write(filenameCourtesyPanel_base64ToBinary(base64Chunk));
        targetFile.close();
        return 'OK';
    } catch (e) {
        return 'FAIL: ' + e;
    }
}
